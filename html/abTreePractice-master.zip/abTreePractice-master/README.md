abTreePractice ([demo](http://alphabeta.alekskamko.com))
==============

D3.js web app for visualizing and understanding the Alpha-Beta Pruning
algorithm.  Developed for UC Berkeley's CS61B.
